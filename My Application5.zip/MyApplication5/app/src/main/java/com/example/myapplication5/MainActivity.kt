package com.example.myapplication5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.myapplication5.ui.theme.MyApplication5Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplication5Theme {
                // Estado de navegación
                var pantalla by remember { mutableStateOf("login") }

                Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
                    when (pantalla) {
                        "login" -> LoginScreen(
                            modifier = Modifier.padding(padding),
                            onLoginSuccess = { pantalla = "registro" }
                        )
                        "registro" -> RegistroScreen(
                            modifier = Modifier.padding(padding),
                            onLogout = { pantalla = "login" },
                            onIrAGalla = { pantalla = "galla" }
                        )
                        "galla" -> GallaScreen(
                            modifier = Modifier.padding(padding),
                            onBack = { pantalla = "registro" }
                        )
                    }
                }
            }
        }
    }
}

// --- 1. PANTALLA DE LOGIN ---
@Composable
fun LoginScreen(modifier: Modifier = Modifier, onLoginSuccess: () -> Unit) {
    var usuario by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF0F2F5))
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Bienvenido", style = MaterialTheme.typography.headlineLarge, color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedTextField(value = usuario, onValueChange = { usuario = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = {
                if (usuario.trim() == "admin" && password.trim() == "1234") onLoginSuccess()
                else mensaje = "❌ Credenciales incorrectas"
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
        ) {
            Text("Iniciar Sesión", fontSize = 18.sp)
        }
        if (mensaje.isNotEmpty()) {
            Text(mensaje, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 16.dp))
        }
    }
}

// --- 2. PANTALLA DE REGISTRO ---
@Composable
fun RegistroScreen(modifier: Modifier = Modifier, onLogout: () -> Unit, onIrAGalla: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var sexo by remember { mutableStateOf("Masculino") }
    var resultado by remember { mutableStateOf("") }

    LazyColumn(modifier = modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Text("Formulario de Registro", style = MaterialTheme.typography.headlineSmall, color = Color(0xFF388E3C))
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(nombre, { nombre = it }, label = { Text("Nombre Completo") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Text("Sexo:", modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(sexo == "Masculino", onClick = { sexo = "Masculino" })
                Text("M")
                Spacer(Modifier.width(20.dp))
                RadioButton(sexo == "Femenino", onClick = { sexo = "Femenino" })
                Text("F")
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onIrAGalla() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))) {
                Text("Ir a Pantalla Galla")
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { resultado = "Registrado: $nombre ($sexo)" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))) {
                Text("Registrar")
            }
            if (resultado.isNotEmpty()) {
                Text(resultado, modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onLogout) {
                Text("Cerrar Sesión", color = Color.Red)
            }
        }
    }
}

// --- 3. PANTALLA GALLA (ACTUALIZADA) ---
@Composable
fun GallaScreen(modifier: Modifier = Modifier, onBack: () -> Unit) {
    var showPopup by remember { mutableStateOf(false) }
    var textAreaValue by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Configuración de ExoPlayer para el video
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            val mediaItem = MediaItem.fromUri("https://vjs.zencdn.net/v/oceans.mp4")
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true // <--- ESTO hará que inicie solo apenas cargue
        }
    }

    // Gestionar el ciclo de vida del reproductor
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // --- BANNER CON IMAGEN REAL ---
        Box(
            modifier = Modifier.fillMaxWidth().height(180.dp).background(Color.Gray),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = "https://picsum.photos/seed/tech/800/400",
                contentDescription = "Banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Surface(color = Color.Black.copy(alpha = 0.4f), modifier = Modifier.align(Alignment.BottomStart)) {
                Text("GALERÍA MULTIMEDIA", color = Color.White, modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold)
            }
        }

        // CONTENIDO CON SCROLL
        LazyColumn(
            modifier = Modifier.weight(1f).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Text("Reproductor de Video", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                // --- VIDEO FUNCIONAL ---
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer } },
                    modifier = Modifier.fillMaxWidth().height(200.dp).background(Color.Black)
                )

                Spacer(Modifier.height(24.dp))

                // --- TEXT AREA (Debajo del video) ---
                Text("Video para conocer la vida marina .", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodyMedium)


                Spacer(Modifier.height(24.dp))

                Button(onClick = { showPopup = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Mostrar Información Extra (Popup)")
                }
            }
        }

        // --- FOOTER ---
        Surface(modifier = Modifier.fillMaxWidth(), color = Color(0xFFE1BEE7)) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("© 2026 - Desarrollo Móvil IUE", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                }
            }
        }
    }

    if (showPopup) {
        AlertDialog(
            onDismissRequest = { showPopup = false },
            confirmButton = { Button(onClick = { showPopup = false }) { Text("Cerrar") } },
            title = { Text("Información") },
            text = { Text("Comentario guardado: \n$textAreaValue") }
        )
    }
}




